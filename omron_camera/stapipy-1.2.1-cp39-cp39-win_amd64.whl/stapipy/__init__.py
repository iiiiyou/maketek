import os
import sys
import importlib

__all__ = []

def bootstrap():
    import copy
    save_sys_path = copy.copy(sys.path)
    
    if hasattr(sys, 'STAPI_LOADER'):
        print(sys.path)
        raise ImportError('ERROR: recursion is detected during loading of "stapipy" binary extensions.')
    sys.STAPI_LOADER = True

    DEBUG = False
    if hasattr(sys, 'STAPI_LOADER_DEBUG'):
        DEBUG = True

    import platform
    if DEBUG: print('stapipy loader: os.name="{}" platform.system()="{}"'.format(os.name, str(platform.system())))

    LOADER_DIR = os.path.dirname(os.path.abspath(os.path.realpath(__file__)))

    PYTHON_EXTENSIONS_PATHS = [LOADER_DIR]

    g_vars = globals()
    l_vars = locals()

    if DEBUG: print(f"stapipy loader: PYTHON_EXTENSIONS_PATHS = {l_vars['PYTHON_EXTENSIONS_PATHS']}")

    applySysPathWorkaround = False
    if hasattr(sys, 'STAPI_REPLACE_SYS_PATH_0'):
        applySysPathWorkaround = True
    else:
        try:
            BASE_DIR = os.path.dirname(LOADER_DIR)
            if sys.path[0] == BASE_DIR or os.path.realpath(sys.path[0]) == BASE_DIR:
                applySysPathWorkaround = True
        except:
            if DEBUG: print("stapipy loader: exception during checking workaround for sys.path[0]")
            pass  # applySysPathWorkaround is False
    
    for p in l_vars['PYTHON_EXTENSIONS_PATHS']:
        sys.path.insert(1 if not applySysPathWorkaround else 0, p)
    
    env_str = ""
    import re
    ptn = re.compile('STAPI_BIN_PATH_V1_2')
    for env in os.environ:
        result = ptn.fullmatch(env)
        if result:
            env_str = result.group()
            break
    if DEBUG: print(f"stapipy loader: env_str = {env_str}")

    if env_str and sys.version_info >= (3, 8):
        for item in os.getenv(env_str).split(';'):
            os.add_dll_directory(item)
            if DEBUG: print(f"stapipy loader: add_dll_directory({item})")
    
    if DEBUG: print("Relink everything from native stapipy module to stapipy package")

    py_module = sys.modules.pop('stapipy')

    native_module = importlib.import_module('stapipy')

    sys.modules['stapipy'] = py_module
    setattr(py_module, 'stapipy', native_module)

    for item_name, item in filter(lambda kv: kv[0] not in ('__file__', '__loader__', '__spec__',
                                                           '__name__', '__package__'),
                                  native_module.__dict__.items()):
        if item_name not in g_vars:
            g_vars[item_name] = item
    
    sys.path = save_sys_path  # multiprocessing should start from bootstrap code

    try:
        del sys.STAPI_LOADER
    except Exception as e:
        if DEBUG:
            print("Exception during delete STAPI_LOADER:", e)
    
    if DEBUG: print("stapipy loader: DONE")

bootstrap()
